"use client";

import type React from "react";
import { useEffect, useRef } from "react";
import Script from "next/script";
import { RegisterForm } from "@/components/register-form";
import {
  HEADLINE_EXPERIMENT,
  defaultVariant,
  parseHeadline,
  type AbVariant,
} from "@/lib/ab";
import { tag, track } from "@/lib/track";

const WISTIA_MEDIA_ID = "7u92v9z9de";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "wistia-player": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      > & {
        "media-id"?: string;
        aspect?: string | number;
      };
    }
  }
}

function StepBar({ step, title }: { step: number; title: string }) {
  return (
    <div
      className="
        flex w-full items-center justify-center gap-2.5
        rounded-full border-[1.5px] border-neutral-300 bg-neutral-50
        px-3.5 py-1.5
        sm:gap-3 sm:px-4 sm:py-2
      "
    >
      <div
        className="
          flex h-5 w-5 shrink-0 items-center justify-center
          rounded-full bg-neutral-900 text-[0.68rem] font-extrabold
          text-white
          sm:h-[1.35rem] sm:w-[1.35rem] sm:text-[0.72rem]
        "
      >
        {step}
      </div>
      <span
        className="
          text-[0.78rem] font-extrabold leading-tight tracking-tight
          text-neutral-900
          sm:text-[0.86rem]
        "
      >
        {title}
      </span>
    </div>
  );
}

interface VslHeroSectionProps {
  /**
   * Which headline to show. Chosen in middleware, read from a cookie in
   * app/page.tsx, rendered here — so the visitor never sees it change.
   * Defaults to the control, which keeps this component usable anywhere.
   */
  variant?: AbVariant;
}

const VSL_MILESTONES = [10, 25, 50, 75, 90] as const;

/**
 * Reports VSL engagement to Clarity: `vsl_play`, `vsl_10` … `vsl_90`,
 * `vsl_complete`, plus a `vsl_watched` tag with the highest milestone, so
 * heatmaps and recordings can be split by how much of the video someone saw.
 * Uses the Aurora <wistia-player> DOM events.
 */
function useVslTracking(ref: React.RefObject<HTMLElement>) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const reached = new Set<number>();
    const onPlay = () => track("vsl_play", { once: true });
    const onEnded = () => {
      track("vsl_complete", { once: true });
      tag("vsl_watched", "100");
    };
    const onPercent = (e: Event) => {
      const detail = (e as CustomEvent).detail ?? {};
      const raw = Number(detail.percentWatched ?? detail.percent ?? 0);
      if (!Number.isFinite(raw)) return;
      const pct = raw <= 1 ? raw * 100 : raw; // docs show 0–1; accept 0–100 too
      for (const m of VSL_MILESTONES) {
        if (pct >= m && !reached.has(m)) {
          reached.add(m);
          track(`vsl_${m}`, { once: true });
          tag("vsl_watched", String(m));
        }
      }
    };

    el.addEventListener("play", onPlay);
    el.addEventListener("ended", onEnded);
    el.addEventListener("percent-watched-change", onPercent);
    return () => {
      el.removeEventListener("play", onPlay);
      el.removeEventListener("ended", onEnded);
      el.removeEventListener("percent-watched-change", onPercent);
    };
  }, [ref]);
}

export function VslHeroSection({ variant }: VslHeroSectionProps) {
  const playerRef = useRef<HTMLElement>(null);
  useVslTracking(playerRef);
  const active = variant ?? defaultVariant();
  const segments = parseHeadline(active.headline);
  const subheadline = active.subheadline ?? HEADLINE_EXPERIMENT.subheadline;

  return (
    <section data-track-section="hero" className="relative w-full overflow-x-hidden bg-white pt-6 font-sans selection:bg-orange-200 sm:pt-8 lg:pt-10">
      <div className="mx-auto w-full max-w-[25rem] px-3 pb-5 min-[390px]:pb-6 sm:max-w-[34rem] sm:px-3.5 sm:pb-8 lg:max-w-3xl lg:px-8 lg:pb-12">
        <div className="flex w-full flex-col items-center text-center">

          {/* Main Headline */}
          <h1
            className="mt-0 w-full text-[1.32rem] font-bold leading-[1.36] tracking-[-0.01em] text-neutral-900 min-[390px]:text-[1.46rem] sm:text-[1.9rem] sm:leading-[1.3] lg:text-[2.3rem] lg:leading-[1.26]"
            style={{ textWrap: "balance" }}
          >
            <span className="block">
              {segments.map((segment, index) =>
                segment.underline ? (
                  <span
                    key={index}
                    className="underline decoration-orange-400 decoration-[3px] underline-offset-4"
                  >
                    {segment.text}
                  </span>
                ) : (
                  <span key={index}>{segment.text}</span>
                )
              )}
            </span>
          </h1>

          {/* Subheadline */}
          <p className="mt-1.5 w-full text-[0.82rem] font-light leading-[1.32] tracking-normal text-neutral-800 min-[390px]:mt-2 min-[390px]:text-[0.9rem] sm:mt-2.5 sm:text-[1.05rem]">
            {subheadline}
          </p>

          {/* KROK 1 — obejrzyj wideo */}
          <div className="mt-5 w-full min-[390px]:mt-6 sm:mt-7">
            <StepBar step={1} title="Obejrzyj wideo poniżej" />
          </div>

          {/* Wistia VSL */}
          <div className="relative mt-3 aspect-video w-full overflow-hidden rounded-2xl bg-black shadow-2xl min-[390px]:mt-3.5 sm:mt-4">
            <Script src="https://fast.wistia.com/player.js" strategy="lazyOnload" />
            <Script
              src={`https://fast.wistia.com/embed/${WISTIA_MEDIA_ID}.js`}
              strategy="lazyOnload"
              type="module"
            />
            <style
              dangerouslySetInnerHTML={{
                __html: `
                  wistia-player[media-id='${WISTIA_MEDIA_ID}']:not(:defined) {
                    background: center / contain no-repeat url('https://fast.wistia.com/embed/medias/${WISTIA_MEDIA_ID}/swatch');
                    display: block;
                    filter: blur(5px);
                    position: absolute;
                    inset: 0;
                    width: 100%;
                    height: 100%;
                  }
                `,
              }}
            />
            <wistia-player
              ref={playerRef}
              media-id={WISTIA_MEDIA_ID}
              aspect="1.7777777777777777"
              className="absolute inset-0 h-full w-full"
            />
          </div>

          {/* KROK 2 — formularz */}
          <div id="zapis" data-track-section="formularz" className="mt-6 w-full scroll-mt-4 min-[390px]:mt-7 sm:mt-8">
            <StepBar step={2} title="Złóż zgłoszenie do programu" />

            <div className="mt-3 flex w-full flex-col items-center min-[390px]:mt-3.5">
              <RegisterForm className="shadow-2xl" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}