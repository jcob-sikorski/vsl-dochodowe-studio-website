-- ===========================================================================
--  Funnel analytics schema
--
--  Run once in Supabase → SQL Editor. Safe to re-run: everything is
--  CREATE ... IF NOT EXISTS / CREATE OR REPLACE.
--
--  Two tables:
--    leads      — one row per person, one timestamp column per funnel stage
--    ad_spend   — one row per ad per day, pulled from the Meta Marketing API
--
--  Funnel stages are cumulative when counted: booked implies qualified,
--  showed implies booked, won implies showed. "Showed" is only ever proven by
--  Proposal Sent or Won; No Show and Lost both count as a missed call. GHL only ever stamps the stage
--  it moved a card to, so the earlier columns stay null on the row.
--
--  Everything else (show rate, cost per qualified lead, cost per show, cost
--  per purchase, ROAS) is a join between them. Nothing is precomputed, so a
--  changed definition never requires a backfill.
-- ===========================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- leads
-- ---------------------------------------------------------------------------
create table if not exists public.leads (
  id                uuid primary key default gen_random_uuid(),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),

  -- identity (ghl_contact_id is the stable key: GHL already dedupes by email)
  ghl_contact_id    text unique,
  email             text,
  phone             text,
  full_name         text,

  -- attribution: IDs first — names get edited, IDs never change
  ad_id             text,
  adset_id          text,
  campaign_id       text,
  utm_source        text,
  utm_medium        text,
  utm_campaign      text,
  utm_content       text,
  utm_term          text,
  utm_id            text,
  fbclid            text,
  fbc               text,
  fbp               text,
  landing_url       text,
  referrer          text,
  traffic_type      text not null default 'organic',  -- 'paid' | 'organic'
  meta_event_id     text,

  -- funnel stages. First occurrence wins; a stage is never un-stamped.
  opted_in_at       timestamptz not null default now(),
  for_qualification_at timestamptz,
  qualified_at      timestamptz,
  booked_at         timestamptz,
  rescheduled_at    timestamptz,
  showed_at         timestamptz,
  no_show_at        timestamptz,
  proposal_sent_at  timestamptz,
  won_at            timestamptz,
  lost_at           timestamptz,
  disqualified_at   timestamptz,

  last_stage        text not null default 'opted_in',
  revenue           numeric(12,2),
  currency          text default 'PLN',

  -- split test the lead opted in under (see lib/ab.ts)
  ab_experiment_id  text,
  ab_variant_id     text,
  ab_visitor_id     text
);

-- Additive, for databases created before these columns existed.
alter table public.leads add column if not exists for_qualification_at timestamptz;
alter table public.leads add column if not exists rescheduled_at       timestamptz;
alter table public.leads add column if not exists proposal_sent_at     timestamptz;
alter table public.leads add column if not exists ab_experiment_id text;
alter table public.leads add column if not exists ab_variant_id    text;
alter table public.leads add column if not exists ab_visitor_id    text;

create index if not exists leads_opted_in_at_idx  on public.leads (opted_in_at desc);
create index if not exists leads_ad_id_idx        on public.leads (ad_id);
create index if not exists leads_campaign_id_idx  on public.leads (campaign_id);
create index if not exists leads_traffic_type_idx on public.leads (traffic_type);
create index if not exists leads_email_idx        on public.leads (lower(email));
create index if not exists leads_ab_variant_idx   on public.leads (ab_experiment_id, ab_variant_id);

-- ---------------------------------------------------------------------------
-- ad_spend
-- ---------------------------------------------------------------------------
create table if not exists public.ad_spend (
  date           date   not null,
  ad_id          text   not null,
  adset_id       text,
  campaign_id    text,
  ad_name        text,
  adset_name     text,
  campaign_name  text,
  spend          numeric(12,2) not null default 0,
  impressions    bigint not null default 0,
  clicks         bigint not null default 0,
  currency       text   default 'PLN',
  synced_at      timestamptz not null default now(),
  primary key (date, ad_id)
);

create index if not exists ad_spend_date_idx        on public.ad_spend (date desc);
create index if not exists ad_spend_campaign_id_idx on public.ad_spend (campaign_id);

-- ---------------------------------------------------------------------------
-- RLS: on, with no policies. The service-role key (server only) bypasses RLS;
-- the anon key can therefore read nothing. Lead PII never reaches a browser.
-- ---------------------------------------------------------------------------
alter table public.leads    enable row level security;
alter table public.ad_spend enable row level security;

-- ---------------------------------------------------------------------------
-- upsert_lead — called by /api/register
--
-- Repeat opt-ins refresh attribution (last touch wins) but never overwrite a
-- stored value with null, and never reset opted_in_at.
-- ---------------------------------------------------------------------------
create or replace function public.upsert_lead(p_lead jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  insert into public.leads as l (
    ghl_contact_id, email, phone, full_name,
    ad_id, adset_id, campaign_id,
    utm_source, utm_medium, utm_campaign, utm_content, utm_term, utm_id,
    fbclid, fbc, fbp, landing_url, referrer,
    traffic_type, meta_event_id,
    ab_experiment_id, ab_variant_id, ab_visitor_id
  )
  values (
    nullif(p_lead->>'ghl_contact_id',''), nullif(p_lead->>'email',''),
    nullif(p_lead->>'phone',''), nullif(p_lead->>'full_name',''),
    nullif(p_lead->>'ad_id',''), nullif(p_lead->>'adset_id',''), nullif(p_lead->>'campaign_id',''),
    nullif(p_lead->>'utm_source',''), nullif(p_lead->>'utm_medium',''), nullif(p_lead->>'utm_campaign',''),
    nullif(p_lead->>'utm_content',''), nullif(p_lead->>'utm_term',''), nullif(p_lead->>'utm_id',''),
    nullif(p_lead->>'fbclid',''), nullif(p_lead->>'fbc',''), nullif(p_lead->>'fbp',''),
    nullif(p_lead->>'landing_url',''), nullif(p_lead->>'referrer',''),
    coalesce(nullif(p_lead->>'traffic_type',''), 'organic'),
    nullif(p_lead->>'meta_event_id',''),
    nullif(p_lead->>'ab_experiment_id',''), nullif(p_lead->>'ab_variant_id',''),
    nullif(p_lead->>'ab_visitor_id','')
  )
  on conflict (ghl_contact_id) do update set
    email         = coalesce(excluded.email, l.email),
    phone         = coalesce(excluded.phone, l.phone),
    full_name     = coalesce(excluded.full_name, l.full_name),
    ad_id         = coalesce(excluded.ad_id, l.ad_id),
    adset_id      = coalesce(excluded.adset_id, l.adset_id),
    campaign_id   = coalesce(excluded.campaign_id, l.campaign_id),
    utm_source    = coalesce(excluded.utm_source, l.utm_source),
    utm_medium    = coalesce(excluded.utm_medium, l.utm_medium),
    utm_campaign  = coalesce(excluded.utm_campaign, l.utm_campaign),
    utm_content   = coalesce(excluded.utm_content, l.utm_content),
    utm_term      = coalesce(excluded.utm_term, l.utm_term),
    utm_id        = coalesce(excluded.utm_id, l.utm_id),
    fbclid        = coalesce(excluded.fbclid, l.fbclid),
    fbc           = coalesce(excluded.fbc, l.fbc),
    fbp           = coalesce(excluded.fbp, l.fbp),
    landing_url   = coalesce(excluded.landing_url, l.landing_url),
    referrer      = coalesce(excluded.referrer, l.referrer),
    -- once paid, always paid: a later direct visit must not erase the ad click
    traffic_type  = case when l.traffic_type = 'paid' then 'paid' else excluded.traffic_type end,
    meta_event_id = coalesce(excluded.meta_event_id, l.meta_event_id),
    -- First assignment sticks: a second opt-in (or a later visit under a new
    -- test) must not re-credit an existing lead to a different headline.
    ab_experiment_id = coalesce(l.ab_experiment_id, excluded.ab_experiment_id),
    ab_variant_id    = coalesce(l.ab_variant_id, excluded.ab_variant_id),
    ab_visitor_id    = coalesce(l.ab_visitor_id, excluded.ab_visitor_id),
    updated_at    = now()
  returning l.id into v_id;

  return v_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- record_lead_stage — called by /api/conversion
--
-- Idempotent by construction: coalesce() means the FIRST time a lead reaches a
-- stage is the time that sticks, so a replayed webhook or a card dragged back
-- and forth can never move a timestamp.
-- ---------------------------------------------------------------------------
create or replace function public.record_lead_stage(
  p_contact_id text,
  p_email      text,
  p_stage      text,
  p_at         timestamptz default now(),
  p_revenue    numeric default null,
  p_currency   text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  select id into v_id
  from public.leads
  where (p_contact_id is not null and ghl_contact_id = p_contact_id)
     or (p_contact_id is null and p_email is not null and lower(email) = lower(p_email))
  order by opted_in_at asc
  limit 1;

  -- A lead that predates this table (or came in through another route) still
  -- gets a row, so the funnel report is never silently missing conversions.
  if v_id is null then
    insert into public.leads (ghl_contact_id, email, opted_in_at, traffic_type, last_stage)
    values (nullif(p_contact_id,''), nullif(p_email,''), p_at, 'organic', p_stage)
    returning id into v_id;
  end if;

  update public.leads set
    for_qualification_at = case when p_stage = 'for_qualification'
                                then coalesce(for_qualification_at, p_at)
                                else for_qualification_at end,
    qualified_at    = case when p_stage = 'qualified'    then coalesce(qualified_at, p_at)    else qualified_at end,
    booked_at       = case when p_stage = 'booked'       then coalesce(booked_at, p_at)       else booked_at end,
    rescheduled_at  = case when p_stage = 'rescheduled'  then coalesce(rescheduled_at, p_at)  else rescheduled_at end,
    showed_at       = case when p_stage = 'showed'       then coalesce(showed_at, p_at)       else showed_at end,
    proposal_sent_at = case when p_stage = 'proposal_sent'
                            then coalesce(proposal_sent_at, p_at)
                            else proposal_sent_at end,
    no_show_at      = case when p_stage = 'no_show'      then coalesce(no_show_at, p_at)      else no_show_at end,
    won_at          = case when p_stage = 'won'          then coalesce(won_at, p_at)          else won_at end,
    lost_at         = case when p_stage = 'lost'         then coalesce(lost_at, p_at)         else lost_at end,
    disqualified_at = case when p_stage = 'disqualified' then coalesce(disqualified_at, p_at) else disqualified_at end,
    revenue         = case when p_stage = 'won' and p_revenue is not null then p_revenue else revenue end,
    currency        = coalesce(nullif(p_currency,''), currency),
    last_stage      = p_stage,
    updated_at      = now()
  where id = v_id;

  return v_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- funnel_report — everything the dashboard reads, in one call
--
-- FULL OUTER JOIN on purpose: an ad with spend and zero leads must still
-- appear. Those rows are the ones costing you money for nothing, and an inner
-- join would hide exactly the thing you most need to see.
-- ---------------------------------------------------------------------------
-- Return type changed on 2026-09-26 (proposals_open); create-or-replace
-- refuses that, so drop first. Safe: nothing depends on this function.
drop function if exists public.funnel_report(date, date, text);

create or replace function public.funnel_report(
  p_from    date,
  p_to      date,
  p_traffic text default 'paid'
)
returns table (
  ad_id         text,
  ad_name       text,
  adset_name    text,
  campaign_name text,
  spend         numeric,
  impressions   bigint,
  clicks        bigint,
  leads             bigint,
  for_qualification bigint,
  qualified         bigint,
  booked            bigint,
  rescheduled       bigint,
  showed            bigint,
  no_shows          bigint,
  no_shows_final    bigint,
  proposal_sent     bigint,
  proposals_open    bigint,
  won               bigint,
  revenue           numeric
)
language sql
stable
security definer
set search_path = public
as $$
  with s as (
    select
      a.ad_id,
      max(a.ad_name)       as ad_name,
      max(a.adset_name)    as adset_name,
      max(a.campaign_name) as campaign_name,
      sum(a.spend)::numeric      as spend,
      sum(a.impressions)::bigint as impressions,
      sum(a.clicks)::bigint      as clicks
    from public.ad_spend a
    where a.date >= p_from and a.date <= p_to
    group by a.ad_id
  ),
  x as (
    -- One flag per lead for "the call happened", so every count below agrees.
    -- Only Proposal Sent or Won proves a held call. Lost does NOT: it is
    -- treated as a no-show, the same as No Show.
    select
      ld.*,
      (ld.proposal_sent_at is not null or ld.won_at is not null) as held
    from public.leads ld
    where ld.opted_in_at >= p_from::timestamptz
      and ld.opted_in_at <  (p_to + 1)::timestamptz
      and (p_traffic = 'all' or ld.traffic_type = p_traffic)
  ),
  l as (
    select
      coalesce(x.ad_id, '(no ad id)') as ad_id,
      count(*)::bigint                   as leads,
      -- Stages are cumulative: reaching one means every earlier one was passed,
      -- whether or not a webhook ever stamped it.
      count(*) filter (where x.for_qualification_at is not null
                          or x.qualified_at     is not null
                          or x.booked_at        is not null
                          or x.rescheduled_at   is not null
                          or x.no_show_at       is not null
                          or x.showed_at        is not null
                          or x.proposal_sent_at is not null
                          or x.lost_at          is not null
                          or x.won_at           is not null)::bigint as for_qualification,
      count(*) filter (where x.qualified_at     is not null
                          or x.booked_at        is not null
                          or x.rescheduled_at   is not null
                          or x.no_show_at       is not null
                          or x.showed_at        is not null
                          or x.proposal_sent_at is not null
                          or x.lost_at          is not null
                          or x.won_at           is not null)::bigint as qualified,
      count(*) filter (where x.booked_at        is not null
                          or x.rescheduled_at   is not null
                          or x.no_show_at       is not null
                          or x.showed_at        is not null
                          or x.proposal_sent_at is not null
                          or x.lost_at          is not null
                          or x.won_at           is not null)::bigint as booked,

      -- Held call = Proposal Sent or Won. Nothing else.
      count(*) filter (where x.held)::bigint as showed,
      count(*) filter (where x.held)::bigint as proposal_sent,

      -- Proposal out, no decision yet: not Won, not Lost.
      count(*) filter (where x.proposal_sent_at is not null
                         and x.won_at  is null
                         and x.lost_at is null)::bigint as proposals_open,

      -- Branches off "booked". A reschedule does not clear booked_at.
      count(x.rescheduled_at)::bigint    as rescheduled,

      -- No Show and Lost both mean the call did not happen. A lead who reached
      -- Proposal Sent / Won held a call, so a later Lost is a lost deal, not a
      -- no-show.
      --   no_shows       — missed at least one call (No Show stamp never clears)
      --   no_shows_final — no-show / lost and never held a call. The real cost.
      count(*) filter (where x.no_show_at is not null
                          or (x.lost_at is not null and not x.held))::bigint as no_shows,
      count(*) filter (where (x.no_show_at is not null or x.lost_at is not null)
                         and not x.held)::bigint as no_shows_final,

      count(x.won_at)::bigint            as won,
      coalesce(sum(x.revenue) filter (where x.won_at is not null), 0)::numeric as revenue
    from x
    group by 1
  )
  select
    coalesce(s.ad_id, l.ad_id)                as ad_id,
    coalesce(s.ad_name, l.ad_id)              as ad_name,
    s.adset_name,
    s.campaign_name,
    coalesce(s.spend, 0)                      as spend,
    coalesce(s.impressions, 0)                as impressions,
    coalesce(s.clicks, 0)                     as clicks,
    coalesce(l.leads, 0)                      as leads,
    coalesce(l.for_qualification, 0)          as for_qualification,
    coalesce(l.qualified, 0)                  as qualified,
    coalesce(l.booked, 0)                     as booked,
    coalesce(l.rescheduled, 0)                as rescheduled,
    coalesce(l.showed, 0)                     as showed,
    coalesce(l.no_shows, 0)                   as no_shows,
    coalesce(l.no_shows_final, 0)             as no_shows_final,
    coalesce(l.proposal_sent, 0)              as proposal_sent,
    coalesce(l.proposals_open, 0)             as proposals_open,
    coalesce(l.won, 0)                        as won,
    coalesce(l.revenue, 0)                    as revenue
  from s
  full outer join l on s.ad_id = l.ad_id
  order by coalesce(s.spend, 0) desc, coalesce(l.leads, 0) desc;
$$;

-- ===========================================================================
--  A/B testing — headline split test
--
--  Two numbers decide a headline: how many people SAW it, and how many of
--  them opted in. Leads already live in public.leads with ab_variant_id
--  stamped on them; this section adds the denominator.
--
--  ab_views holds one row per browser per experiment, not one per pageview.
--  A rate whose denominator counts reloads is not an opt-in rate, and a
--  visitor who opens the page five times before filling in the form would
--  otherwise look like four failures and one success.
-- ===========================================================================

create table if not exists public.ab_views (
  id              uuid primary key default gen_random_uuid(),
  experiment_id   text not null,
  variant_id      text not null,
  visitor_id      text not null,

  first_seen_at   timestamptz not null default now(),
  last_seen_at    timestamptz not null default now(),
  views           integer not null default 1,

  traffic_type    text not null default 'organic',   -- 'paid' | 'organic'
  ad_id           text,
  adset_id        text,
  campaign_id     text,
  utm_source      text,
  utm_medium      text,
  utm_campaign    text,
  utm_content     text,
  landing_url     text,
  referrer        text,
  user_agent      text,

  -- One row per browser per experiment. This constraint IS the de-duplication.
  unique (experiment_id, visitor_id)
);

create index if not exists ab_views_first_seen_idx on public.ab_views (first_seen_at desc);
create index if not exists ab_views_variant_idx    on public.ab_views (experiment_id, variant_id);
create index if not exists ab_views_traffic_idx    on public.ab_views (traffic_type);

alter table public.ab_views enable row level security;

-- ---------------------------------------------------------------------------
-- record_ab_view — called by /api/ab/view
--
-- The variant is never rewritten on conflict: whichever headline a browser saw
-- first is the one it is counted under for the life of the experiment, even if
-- cookies are edited or the config changes underneath them.
-- ---------------------------------------------------------------------------
create or replace function public.record_ab_view(p_view jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  insert into public.ab_views as v (
    experiment_id, variant_id, visitor_id,
    traffic_type, ad_id, adset_id, campaign_id,
    utm_source, utm_medium, utm_campaign, utm_content,
    landing_url, referrer, user_agent
  )
  values (
    nullif(p_view->>'experiment_id',''),
    nullif(p_view->>'variant_id',''),
    nullif(p_view->>'visitor_id',''),
    coalesce(nullif(p_view->>'traffic_type',''), 'organic'),
    nullif(p_view->>'ad_id',''), nullif(p_view->>'adset_id',''), nullif(p_view->>'campaign_id',''),
    nullif(p_view->>'utm_source',''), nullif(p_view->>'utm_medium',''),
    nullif(p_view->>'utm_campaign',''), nullif(p_view->>'utm_content',''),
    nullif(p_view->>'landing_url',''), nullif(p_view->>'referrer',''),
    nullif(p_view->>'user_agent','')
  )
  on conflict (experiment_id, visitor_id) do update set
    last_seen_at = now(),
    views        = v.views + 1,
    -- once paid, always paid: a later direct visit must not erase the ad click
    traffic_type = case when v.traffic_type = 'paid' then 'paid' else excluded.traffic_type end,
    ad_id        = coalesce(v.ad_id, excluded.ad_id),
    adset_id     = coalesce(v.adset_id, excluded.adset_id),
    campaign_id  = coalesce(v.campaign_id, excluded.campaign_id),
    utm_source   = coalesce(v.utm_source, excluded.utm_source),
    utm_medium   = coalesce(v.utm_medium, excluded.utm_medium),
    utm_campaign = coalesce(v.utm_campaign, excluded.utm_campaign),
    utm_content  = coalesce(v.utm_content, excluded.utm_content)
  returning v.id into v_id;

  return v_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- ab_report — views, opt-ins and everything downstream, per variant
--
-- FULL OUTER JOIN for the same reason funnel_report uses one: a variant with
-- views and zero leads is the single most important row on the page, and an
-- inner join would delete it.
--
-- p_traffic 'paid' | 'organic' | 'all'. Compare like with like — a variant
-- judged on mixed traffic is really being judged on whichever traffic mix it
-- happened to get.
-- ---------------------------------------------------------------------------
-- Meta's ad review loads the page in bursts whenever ads are published; those
-- visits are scored here and left out of the test. See migration 2026-10-07.
create or replace view public.ab_views_scored
with (security_invoker = true) as
with hourly as (
  select
    v.experiment_id,
    date_trunc('hour', v.first_seen_at)          as hr,
    count(distinct v.id)                         as visitors,
    count(distinct v.id) filter (where v.views > 1) as returning_visitors,
    count(distinct l.id)                         as opt_ins
  from public.ab_views v
  left join public.leads l
    on l.ab_experiment_id = v.experiment_id
   and l.ab_visitor_id    = v.visitor_id
  group by 1, 2
)
select
  v.*,
  (h.visitors >= 20 and h.returning_visitors = 0 and h.opt_ins = 0) as is_review_burst
from public.ab_views v
join hourly h
  on h.experiment_id = v.experiment_id
 and h.hr            = date_trunc('hour', v.first_seen_at);

revoke all on public.ab_views_scored from anon, authenticated;
grant select on public.ab_views_scored to service_role;

drop function if exists public.ab_report(date, date, text, text);

create or replace function public.ab_report(
  p_from       date,
  p_to         date,
  p_traffic    text default 'all',
  p_experiment text default null
)
returns table (
  experiment_id  text,
  variant_id     text,
  views          bigint,
  excluded_views bigint,
  leads          bigint,
  qualified      bigint,
  booked         bigint,
  showed         bigint,
  won            bigint,
  revenue        numeric
)
language sql
stable
security definer
set search_path = public
as $$
  with v as (
    select
      x.experiment_id,
      x.variant_id,
      count(*) filter (where not x.is_review_burst)::bigint as views,
      count(*) filter (where x.is_review_burst)::bigint     as excluded_views
    from public.ab_views_scored x
    where x.first_seen_at >= p_from::timestamptz
      and x.first_seen_at <  (p_to + 1)::timestamptz
      and (p_traffic = 'all' or x.traffic_type = p_traffic)
      and (p_experiment is null or x.experiment_id = p_experiment)
    group by 1, 2
  ),
  l as (
    select
      x.ab_experiment_id as experiment_id,
      x.ab_variant_id    as variant_id,
      count(*)::bigint              as leads,
      -- Cumulative, same rule as funnel_report.
      count(*) filter (where x.qualified_at     is not null
                          or x.booked_at        is not null
                          or x.rescheduled_at   is not null
                          or x.no_show_at       is not null
                          or x.showed_at        is not null
                          or x.proposal_sent_at is not null
                          or x.lost_at          is not null
                          or x.won_at           is not null)::bigint as qualified,
      count(*) filter (where x.booked_at        is not null
                          or x.rescheduled_at   is not null
                          or x.no_show_at       is not null
                          or x.showed_at        is not null
                          or x.proposal_sent_at is not null
                          or x.lost_at          is not null
                          or x.won_at           is not null)::bigint as booked,
      -- Held call = Proposal Sent or Won, same rule as funnel_report.
      count(*) filter (where x.proposal_sent_at is not null
                          or x.won_at           is not null)::bigint as showed,
      count(x.won_at)::bigint       as won,
      coalesce(sum(x.revenue) filter (where x.won_at is not null), 0)::numeric as revenue
    from public.leads x
    where x.opted_in_at >= p_from::timestamptz
      and x.opted_in_at <  (p_to + 1)::timestamptz
      and (p_traffic = 'all' or x.traffic_type = p_traffic)
      and x.ab_variant_id is not null
      and (p_experiment is null or x.ab_experiment_id = p_experiment)
    group by 1, 2
  )
  select
    coalesce(v.experiment_id, l.experiment_id) as experiment_id,
    coalesce(v.variant_id, l.variant_id)       as variant_id,
    coalesce(v.views, 0)                       as views,
    coalesce(v.excluded_views, 0)              as excluded_views,
    coalesce(l.leads, 0)                       as leads,
    coalesce(l.qualified, 0)                   as qualified,
    coalesce(l.booked, 0)                      as booked,
    coalesce(l.showed, 0)                      as showed,
    coalesce(l.won, 0)                         as won,
    coalesce(l.revenue, 0)                     as revenue
  from v
  full outer join l
    on v.experiment_id = l.experiment_id
   and v.variant_id    = l.variant_id
  order by 1, 2;
$$;

-- Server-only, like everything else here. Recreating the function reset its
-- grants to Supabase's defaults, which include the public anon role.
revoke execute on function public.ab_report(date, date, text, text) from public, anon, authenticated;
grant execute on function public.ab_report(date, date, text, text) to service_role;


-- ===========================================================================
--  Call history (2026-10-07). Supersedes record_lead_stage, funnel_report and
--  ab_report above. Kept verbatim from supabase/migrations/2026-10-07_call_history.sql
-- ===========================================================================
-- 1. event log ---------------------------------------------------------------
create table if not exists public.lead_stage_events (
  id          bigint generated always as identity primary key,
  lead_id     uuid        not null references public.leads (id) on delete cascade,
  stage       text        not null,
  occurred_at timestamptz not null,
  received_at timestamptz not null default now(),
  source      text        not null default 'webhook'   -- 'webhook' | 'backfill'
);

create index if not exists lead_stage_events_lead_idx
  on public.lead_stage_events (lead_id, occurred_at, id);

alter table public.lead_stage_events enable row level security;
revoke all on public.lead_stage_events from anon, authenticated;
grant select, insert on public.lead_stage_events to service_role;

-- Backfill once from the stamps we have.
insert into public.lead_stage_events (lead_id, stage, occurred_at, source)
select l.id, s.stage, s.at, 'backfill'
from public.leads l
cross join lateral (values
  (1, 'for_qualification', l.for_qualification_at),
  (2, 'qualified',         l.qualified_at),
  (3, 'booked',            l.booked_at),
  (4, 'rescheduled',       l.rescheduled_at),
  (5, 'no_show',           l.no_show_at),
  (6, 'showed',            l.showed_at),
  (7, 'proposal_sent',     l.proposal_sent_at),
  (8, 'lost',              l.lost_at),
  (9, 'disqualified',      l.disqualified_at),
  (10, 'won',              l.won_at)
) as s(ord, stage, at)
where s.at is not null
  and not exists (select 1 from public.lead_stage_events e where e.source = 'backfill')
order by l.id, s.at, s.ord;

-- 2. record_lead_event --------------------------------------------------------
create or replace function public.record_lead_event(
  p_contact_id text,
  p_email      text,
  p_stage      text,
  p_at         timestamptz default now(),
  p_revenue    numeric default null,
  p_currency   text default null
)
returns table (lead_id uuid, first_time boolean)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id    uuid;
  v_first boolean;
begin
  select l.id into v_id
  from public.leads l
  where (p_contact_id is not null and l.ghl_contact_id = p_contact_id)
     or (p_contact_id is null and p_email is not null and lower(l.email) = lower(p_email))
  order by l.opted_in_at asc
  limit 1;

  -- A lead that predates this table (or came in another way) still gets a row.
  if v_id is null then
    insert into public.leads (ghl_contact_id, email, opted_in_at, traffic_type, last_stage)
    values (nullif(p_contact_id,''), nullif(p_email,''), p_at, 'organic', p_stage)
    returning id into v_id;
  end if;

  v_first := not exists (
    select 1 from public.lead_stage_events e where e.lead_id = v_id and e.stage = p_stage
  );

  insert into public.lead_stage_events (lead_id, stage, occurred_at)
  values (v_id, p_stage, coalesce(p_at, now()));

  -- First-occurrence stamps, unchanged: they still feed the cohort funnel.
  update public.leads set
    for_qualification_at = case when p_stage = 'for_qualification' then coalesce(for_qualification_at, p_at) else for_qualification_at end,
    qualified_at     = case when p_stage = 'qualified'     then coalesce(qualified_at, p_at)     else qualified_at end,
    booked_at        = case when p_stage = 'booked'        then coalesce(booked_at, p_at)        else booked_at end,
    rescheduled_at   = case when p_stage = 'rescheduled'   then coalesce(rescheduled_at, p_at)   else rescheduled_at end,
    showed_at        = case when p_stage = 'showed'        then coalesce(showed_at, p_at)        else showed_at end,
    proposal_sent_at = case when p_stage = 'proposal_sent' then coalesce(proposal_sent_at, p_at) else proposal_sent_at end,
    no_show_at       = case when p_stage = 'no_show'       then coalesce(no_show_at, p_at)       else no_show_at end,
    won_at           = case when p_stage = 'won'           then coalesce(won_at, p_at)           else won_at end,
    lost_at          = case when p_stage = 'lost'          then coalesce(lost_at, p_at)          else lost_at end,
    disqualified_at  = case when p_stage = 'disqualified'  then coalesce(disqualified_at, p_at)  else disqualified_at end,
    revenue          = case when p_stage = 'won' and p_revenue is not null then p_revenue else revenue end,
    currency         = coalesce(nullif(p_currency,''), currency),
    last_stage       = p_stage,
    updated_at       = now()
  where id = v_id;

  lead_id    := v_id;
  first_time := v_first;
  return next;
end;
$$;

-- The running app calls this; it now goes through the event log too.
create or replace function public.record_lead_stage(
  p_contact_id text,
  p_email      text,
  p_stage      text,
  p_at         timestamptz default now(),
  p_revenue    numeric default null,
  p_currency   text default null
)
returns uuid
language sql
security definer
set search_path = public
as $$
  select r.lead_id from public.record_lead_event(p_contact_id, p_email, p_stage, p_at, p_revenue, p_currency) r;
$$;

-- 3. lead_calls ---------------------------------------------------------------
create or replace function public.lead_calls()
returns table (
  lead_id    uuid,
  call_no    integer,
  booked_at  timestamptz,
  outcome    text,          -- 'held' | 'no_show' | 'returned' | 'pending'
  outcome_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  r      record;
  v_lead uuid;
  v_open timestamptz;          -- booking time of the call in progress, if any
  v_n    integer := 0;
  v_last text;                 -- outcome of the most recent call: held | no_show
begin
  for r in
    select e.lead_id as lid, e.stage as st, e.occurred_at as at
    from public.lead_stage_events e
    order by e.lead_id, e.occurred_at, e.id
  loop
    if v_lead is distinct from r.lid then
      if v_open is not null then
        lead_id := v_lead; call_no := v_n; booked_at := v_open; outcome := 'pending'; outcome_at := null;
        return next;
      end if;
      v_lead := r.lid; v_open := null; v_n := 0; v_last := null;
    end if;

    if r.st in ('booked', 'rescheduled') then
      -- A repeat webhook for the same booking changes nothing.
      if v_open is null then
        v_open := r.at; v_n := v_n + 1;
      end if;

    elsif r.st = 'no_show' then
      if v_open is not null then
        lead_id := v_lead; call_no := v_n; booked_at := v_open; outcome := 'no_show'; outcome_at := r.at;
        return next;
        v_open := null; v_last := 'no_show';
      elsif v_last is distinct from 'no_show' then
        -- Straight to No Show without a Booked Call event: still a missed call.
        v_n := v_n + 1;
        lead_id := v_lead; call_no := v_n; booked_at := r.at; outcome := 'no_show'; outcome_at := r.at;
        return next;
        v_last := 'no_show';
      end if;

    elsif r.st in ('proposal_sent', 'won', 'lost', 'showed', 'disqualified') then
      if v_open is not null then
        lead_id := v_lead; call_no := v_n; booked_at := v_open; outcome := 'held'; outcome_at := r.at;
        return next;
        v_open := null; v_last := 'held';
      elsif v_last = 'no_show' and r.st in ('proposal_sent', 'won', 'showed') then
        -- No Show → Proposal Sent / Won: they talked after all.
        v_n := v_n + 1;
        lead_id := v_lead; call_no := v_n; booked_at := r.at; outcome := 'held'; outcome_at := r.at;
        return next;
        v_last := 'held';
      end if;
      -- Otherwise a decision on an earlier call, or a drop-off before booking.

    elsif r.st in ('for_qualification', 'qualified') then
      if v_open is not null then
        lead_id := v_lead; call_no := v_n; booked_at := v_open; outcome := 'returned'; outcome_at := r.at;
        return next;
        v_open := null;
      end if;
      v_last := null;
    end if;
  end loop;

  if v_open is not null then
    lead_id := v_lead; call_no := v_n; booked_at := v_open; outcome := 'pending'; outcome_at := null;
    return next;
  end if;
end;
$$;

-- 4a. funnel_report -----------------------------------------------------------
drop function if exists public.funnel_report(date, date, text);

create or replace function public.funnel_report(
  p_from    date,
  p_to      date,
  p_traffic text default 'paid'
)
returns table (
  ad_id             text,
  ad_name           text,
  adset_name        text,
  campaign_name     text,
  spend             numeric,
  impressions       bigint,
  clicks            bigint,
  leads             bigint,
  for_qualification bigint,
  qualified         bigint,
  booked            bigint,   -- leads with at least one call booked
  rescheduled       bigint,   -- leads booked more than once
  showed            bigint,   -- leads with at least one held call
  no_shows          bigint,   -- leads that missed at least one call
  no_shows_final    bigint,   -- leads whose every resolved call was missed
  proposal_sent     bigint,
  proposals_open    bigint,   -- card sitting in Proposal Sent right now
  won               bigint,
  revenue           numeric,
  calls             bigint,   -- every booking
  calls_held        bigint,
  calls_no_show     bigint,
  calls_pending     bigint,
  calls_returned    bigint,   -- sent back to For Qualification before the call
  calls_stale       bigint    -- pending 7+ days after booking: card probably not moved
)
language sql
stable
security definer
set search_path = public
as $$
  with s as (
    select
      a.ad_id,
      max(a.ad_name)       as ad_name,
      max(a.adset_name)    as adset_name,
      max(a.campaign_name) as campaign_name,
      sum(a.spend)::numeric      as spend,
      sum(a.impressions)::bigint as impressions,
      sum(a.clicks)::bigint      as clicks
    from public.ad_spend a
    where a.date >= p_from and a.date <= p_to
    group by a.ad_id
  ),
  x as (
    select ld.*
    from public.leads ld
    where ld.opted_in_at >= p_from::timestamptz
      and ld.opted_in_at <  (p_to + 1)::timestamptz
      and (p_traffic = 'all' or ld.traffic_type = p_traffic)
  ),
  c as (
    select
      lc.lead_id,
      count(*)                                          as n,
      count(*) filter (where lc.outcome = 'held')       as held,
      count(*) filter (where lc.outcome = 'no_show')    as no_show,
      count(*) filter (where lc.outcome = 'pending')    as pending,
      count(*) filter (where lc.outcome = 'returned')   as returned,
      count(*) filter (where lc.outcome = 'pending'
                         and lc.booked_at < now() - interval '7 days') as stale
    from public.lead_calls() lc
    where lc.lead_id in (select x.id from x)
    group by 1
  ),
  l as (
    select
      coalesce(x.ad_id, '(no ad id)') as ad_id,
      count(*)::bigint as leads,
      -- Every lead in the pipeline passes through For Qualification.
      count(*) filter (where x.for_qualification_at is not null
                          or x.qualified_at is not null
                          or c.n > 0
                          or x.lost_at is not null)::bigint                    as for_qualification,
      count(*) filter (where x.qualified_at is not null or c.n > 0)::bigint   as qualified,
      count(*) filter (where c.n > 0)::bigint                                  as booked,
      count(*) filter (where c.n > 1)::bigint                                  as rescheduled,
      count(*) filter (where c.held > 0)::bigint                               as showed,
      count(*) filter (where c.no_show > 0)::bigint                            as no_shows,
      count(*) filter (where c.no_show > 0 and c.held = 0 and c.pending = 0)::bigint as no_shows_final,
      count(x.proposal_sent_at)::bigint                                        as proposal_sent,
      count(*) filter (where x.last_stage = 'proposal_sent')::bigint           as proposals_open,
      count(x.won_at)::bigint                                                  as won,
      coalesce(sum(x.revenue) filter (where x.won_at is not null), 0)::numeric as revenue,
      coalesce(sum(c.n), 0)::bigint        as calls,
      coalesce(sum(c.held), 0)::bigint     as calls_held,
      coalesce(sum(c.no_show), 0)::bigint  as calls_no_show,
      coalesce(sum(c.pending), 0)::bigint  as calls_pending,
      coalesce(sum(c.returned), 0)::bigint as calls_returned,
      coalesce(sum(c.stale), 0)::bigint    as calls_stale
    from x
    left join c on c.lead_id = x.id
    group by 1
  )
  select
    coalesce(s.ad_id, l.ad_id)       as ad_id,
    coalesce(s.ad_name, l.ad_id)     as ad_name,
    s.adset_name,
    s.campaign_name,
    coalesce(s.spend, 0)             as spend,
    coalesce(s.impressions, 0)       as impressions,
    coalesce(s.clicks, 0)            as clicks,
    coalesce(l.leads, 0)             as leads,
    coalesce(l.for_qualification, 0) as for_qualification,
    coalesce(l.qualified, 0)         as qualified,
    coalesce(l.booked, 0)            as booked,
    coalesce(l.rescheduled, 0)       as rescheduled,
    coalesce(l.showed, 0)            as showed,
    coalesce(l.no_shows, 0)          as no_shows,
    coalesce(l.no_shows_final, 0)    as no_shows_final,
    coalesce(l.proposal_sent, 0)     as proposal_sent,
    coalesce(l.proposals_open, 0)    as proposals_open,
    coalesce(l.won, 0)               as won,
    coalesce(l.revenue, 0)           as revenue,
    coalesce(l.calls, 0)             as calls,
    coalesce(l.calls_held, 0)        as calls_held,
    coalesce(l.calls_no_show, 0)     as calls_no_show,
    coalesce(l.calls_pending, 0)     as calls_pending,
    coalesce(l.calls_returned, 0)    as calls_returned,
    coalesce(l.calls_stale, 0)       as calls_stale
  from s
  full outer join l on s.ad_id = l.ad_id
  order by coalesce(s.spend, 0) desc, coalesce(l.leads, 0) desc;
$$;

-- 4b. ab_report: same booking/show rules -------------------------------------
create or replace function public.ab_report(
  p_from       date,
  p_to         date,
  p_traffic    text default 'all',
  p_experiment text default null
)
returns table (
  experiment_id  text,
  variant_id     text,
  views          bigint,
  excluded_views bigint,
  leads          bigint,
  qualified      bigint,
  booked         bigint,
  showed         bigint,
  won            bigint,
  revenue        numeric
)
language sql
stable
security definer
set search_path = public
as $$
  with v as (
    select
      x.experiment_id,
      x.variant_id,
      count(*) filter (where not x.is_review_burst)::bigint as views,
      count(*) filter (where x.is_review_burst)::bigint     as excluded_views
    from public.ab_views_scored x
    where x.first_seen_at >= p_from::timestamptz
      and x.first_seen_at <  (p_to + 1)::timestamptz
      and (p_traffic = 'all' or x.traffic_type = p_traffic)
      and (p_experiment is null or x.experiment_id = p_experiment)
    group by 1, 2
  ),
  c as (
    select lc.lead_id, count(*) as n, count(*) filter (where lc.outcome = 'held') as held
    from public.lead_calls() lc
    group by 1
  ),
  l as (
    select
      x.ab_experiment_id as experiment_id,
      x.ab_variant_id    as variant_id,
      count(*)::bigint                                                         as leads,
      count(*) filter (where x.qualified_at is not null or c.n > 0)::bigint   as qualified,
      count(*) filter (where c.n > 0)::bigint                                  as booked,
      count(*) filter (where c.held > 0)::bigint                               as showed,
      count(x.won_at)::bigint                                                  as won,
      coalesce(sum(x.revenue) filter (where x.won_at is not null), 0)::numeric as revenue
    from public.leads x
    left join c on c.lead_id = x.id
    where x.opted_in_at >= p_from::timestamptz
      and x.opted_in_at <  (p_to + 1)::timestamptz
      and (p_traffic = 'all' or x.traffic_type = p_traffic)
      and x.ab_variant_id is not null
      and (p_experiment is null or x.ab_experiment_id = p_experiment)
    group by 1, 2
  )
  select
    coalesce(v.experiment_id, l.experiment_id) as experiment_id,
    coalesce(v.variant_id, l.variant_id)       as variant_id,
    coalesce(v.views, 0)                       as views,
    coalesce(v.excluded_views, 0)              as excluded_views,
    coalesce(l.leads, 0)                       as leads,
    coalesce(l.qualified, 0)                   as qualified,
    coalesce(l.booked, 0)                      as booked,
    coalesce(l.showed, 0)                      as showed,
    coalesce(l.won, 0)                         as won,
    coalesce(l.revenue, 0)                     as revenue
  from v
  full outer join l
    on v.experiment_id = l.experiment_id
   and v.variant_id    = l.variant_id
  order by 1, 2;
$$;

-- 5. server-only --------------------------------------------------------------
do $$
declare f text;
begin
  foreach f in array array[
    'public.upsert_lead(jsonb)',
    'public.record_ab_view(jsonb)',
    'public.record_lead_stage(text, text, text, timestamptz, numeric, text)',
    'public.record_lead_event(text, text, text, timestamptz, numeric, text)',
    'public.lead_calls()',
    'public.funnel_report(date, date, text)',
    'public.ab_report(date, date, text, text)'
  ] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end $$;
